import UIKit

print("Hello World of Swift")
print("I am Connar")
print("I have a little coding experience, working through books for the last 7 months")
print("I can't wait to build my own applications/work independently")

var favouriteBand = ("Imagine Dragons")
var favouriteSong = ("Believer")

print("my favourite Band is: \(favouriteBand) and my favourite Song is: \(favouriteSong)")

